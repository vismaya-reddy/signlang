'use client';

import { useState, useEffect } from 'react';
import { userAPI } from '@/lib/auth-api';

export interface UserStats {
  name: string;
  xp: number;
  level: number;
  streak: number;
  lessonsCompleted: number;
  accuracy: number;
  loading: boolean;
  error: string | null;
}

const defaultStats: UserStats = {
  name: 'Sign Learner',
  xp: 0,
  level: 1,
  streak: 0,
  lessonsCompleted: 0,
  accuracy: 0,
  loading: true,
  error: null,
};

export function useUserStats() {
  const [stats, setStats] = useState<UserStats>(defaultStats);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        setStats(prev => ({ ...prev, loading: true, error: null }));
        const data = await userAPI.getStats();
        setStats({
          name: data.user?.full_name || 'Sign Learner',
          xp: data.stats?.xp || 0,
          level: data.stats?.level || 1,
          streak: data.stats?.streak || 0,
          lessonsCompleted: data.stats?.lessons_completed || 0,
          accuracy: data.stats?.accuracy || 0,
          loading: false,
          error: null,
        });
      } catch (error: any) {
        console.error('Failed to fetch user stats:', error);
        setStats(prev => ({
          ...prev,
          loading: false,
          error: error.message || 'Failed to fetch stats',
        }));
      }
    };

    fetchStats();
  }, []);

  return stats;
}
