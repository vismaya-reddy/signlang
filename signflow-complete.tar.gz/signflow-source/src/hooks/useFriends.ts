'use client';

import { useState, useEffect } from 'react';
import { socialAPI } from '@/lib/auth-api';

export interface Friend {
  id: string;
  name: string;
  xp: number;
  level: number;
  avatar?: string;
  lastActive?: string;
}

export function useFriends() {
  const [friends, setFriends] = useState<Friend[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchFriends = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await socialAPI.getFriends();
        setFriends(data.friends || []);
      } catch (err: any) {
        console.error('Failed to fetch friends:', err);
        setError(err.message || 'Failed to fetch friends');
        // Set mock data for development
        setFriends([
          { id: '1', name: 'Alex Chen', xp: 3200, level: 5 },
          { id: '2', name: 'Jordan Lee', xp: 2900, level: 4 },
          { id: '3', name: 'Sam Park', xp: 2600, level: 4 },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchFriends();
  }, []);

  const addFriend = async (userId: string) => {
    try {
      await socialAPI.addFriend(userId);
      // Refresh friends list
      const data = await socialAPI.getFriends();
      setFriends(data.friends || []);
    } catch (err: any) {
      console.error('Failed to add friend:', err);
      throw err;
    }
  };

  const removeFriend = async (userId: string) => {
    try {
      await socialAPI.removeFriend(userId);
      setFriends(friends.filter(f => f.id !== userId));
    } catch (err: any) {
      console.error('Failed to remove friend:', err);
      throw err;
    }
  };

  return { friends, loading, error, addFriend, removeFriend };
}
