'use client';

import { useState, useRef, useEffect } from 'react';

/**
 * MediaPipe Gesture Recognition Hook
 * - Accesses webcam
 * - Detects hand landmarks
 * - Calculates accuracy scores
 */

export interface GestureResult {
  gesture: string;
  confidence: number;
  landmarks: Array<{ x: number; y: number; z: number; visibility: number }>;
  accuracy: number;
}

export function useGestureRecognition() {
  const [isActive, setIsActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<GestureResult | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = async () => {
    try {
      setError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsActive(true);
      }
    } catch (err: any) {
      const message = err.message || 'Failed to access camera';
      setError(message);
      console.error('Camera error:', err);
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
      setIsActive(false);
    }
  };

  const captureFrame = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(videoRef.current, 0, 0);
    const frameData = canvasRef.current.toDataURL('image/jpeg');

    try {
      const response = await fetch('/api/mediapipe-gesture', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ frameData }),
      });

      if (!response.ok) throw new Error('Gesture recognition failed');

      const data = await response.json();
      setResult(data.gesture || null);
    } catch (err: any) {
      console.error('Gesture capture error:', err);
      setError(err.message);
    }
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  return {
    videoRef,
    canvasRef,
    isActive,
    error,
    result,
    startCamera,
    stopCamera,
    captureFrame,
  };
}
