'use client';

import { useState, useEffect } from 'react';
import { learningAPI } from '@/lib/auth-api';

export interface Lesson {
  id: string | number;
  title: string;
  description: string;
  videoUrl?: string;
  content?: string;
  completed?: boolean;
  accuracy?: number;
}

export function useLessons(moduleId?: string | number) {
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!moduleId) {
      setLoading(false);
      return;
    }

    const fetchLessons = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await learningAPI.getLesson(moduleId);
        setLessons(Array.isArray(data) ? data : [data]);
      } catch (err: any) {
        console.error('Failed to fetch lessons:', err);
        setError(err.message || 'Failed to fetch lessons');
      } finally {
        setLoading(false);
      }
    };

    fetchLessons();
  }, [moduleId]);

  return { lessons, loading, error };
}
