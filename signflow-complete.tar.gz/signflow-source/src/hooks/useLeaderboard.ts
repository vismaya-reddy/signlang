'use client';

import { useState, useEffect } from 'react';
import { socialAPI } from '@/lib/auth-api';

export interface LeaderboardEntry {
  rank: number;
  userId: string;
  name: string;
  xp: number;
  level: number;
  avatar?: string;
}

export function useLeaderboard(limit = 10) {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchLeaderboard = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await socialAPI.getLeaderboard(limit);
        setEntries(data.leaderboard || []);
      } catch (err: any) {
        console.error('Failed to fetch leaderboard:', err);
        setError(err.message || 'Failed to fetch leaderboard');
        // Set mock data for development
        setEntries([
          { rank: 1, userId: '1', name: 'Alex Chen', xp: 5000, level: 8 },
          { rank: 2, userId: '2', name: 'Jordan Lee', xp: 4500, level: 7 },
          { rank: 3, userId: '3', name: 'Sam Park', xp: 4200, level: 7 },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchLeaderboard();
  }, [limit]);

  return { entries, loading, error };
}
