import { NextRequest, NextResponse } from 'next/server';
import { OpenAI } from 'openai';
import { addMessage } from '@/lib/supabase';

/**
 * AI LLM Chat Backend - Production Ready with OpenAI
 * 
 * This endpoint handles intelligent conversational AI for sign language learning
 * Features:
 * - Maintains conversation context/memory
 * - Emotion-aware responses
 * - Educational guidance
 * - Real-time corrections
 * - Multiple response modes (text, voice-ready, sign animation hints)
 */

interface ChatRequest {
  conversationId: string;
  userId: string;
  message: string;
  context?: {
    currentLesson?: string;
    userLevel?: number;
    emotionalState?: string;
    recentErrors?: string[];
  };
}

interface ChatResponse {
  messageId: string;
  content: string;
  hasAudio: boolean;
  hasSignAnimation: boolean;
  suggestions?: string[];
  nextSteps?: string[];
}

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const systemPrompt = `You are SignFlow, an expert sign language learning assistant. Your role is to:

1. TEACH sign language concepts with clarity and enthusiasm
2. PROVIDE real-time corrections when users make mistakes
3. ENCOURAGE users and maintain positive momentum
4. ADAPT your teaching style based on the user's level and emotional state
5. GIVE specific, actionable feedback for improvement
6. USE encouraging language while being honest about areas for improvement

Context awareness:
- Understand the user's current lesson and adapt explanations accordingly
- Remember previous interactions in this conversation
- Provide progressively challenging material as users improve
- Celebrate achievements and milestones

Response format:
- Keep responses concise but informative (2-4 sentences typically)
- Use clear, accessible language
- Include one suggestion or action item when relevant
- Format responses for both text and voice delivery`;

export async function POST(request: NextRequest) {
  try {
    const { conversationId, userId, message, context } = (await request.json()) as ChatRequest;

    if (!conversationId || !userId || !message) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Store user message
    await addMessage(conversationId, userId, 'user', message, false, false);

    // Build context for AI
    const contextString = context
      ? `Current context:
    - Current Lesson: ${context.currentLesson || 'General'}
    - User Level: ${context.userLevel || 1}
    - Emotional State: ${context.emotionalState || 'neutral'}
    - Recent Errors: ${context.recentErrors?.join(', ') || 'None'}`
      : '';

    // Get AI response using OpenAI
    const messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }> = [
      {
        role: 'system',
        content: systemPrompt + (contextString ? `\n\n${contextString}` : ''),
      },
      {
        role: 'user',
        content: message,
      },
    ];

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini', // or 'gpt-4' for higher quality
      messages,
      temperature: 0.7,
      max_tokens: 500,
      stream: false,
    });

    const aiContent = completion.choices[0]?.message?.content || '';

    if (!aiContent) {
      throw new Error('No response from OpenAI');
    }

    // Extract suggestions from response
    const suggestions = extractSuggestions(aiContent);

    // Store AI response
    const aiMessage = await addMessage(
      conversationId,
      userId,
      'assistant',
      aiContent,
      true, // hasAudio - can be synthesized
      true  // hasSignAnimation - can show relevant signs
    );

    const response: ChatResponse = {
      messageId: aiMessage?.id || `msg_${Date.now()}`,
      content: aiContent,
      hasAudio: true,
      hasSignAnimation: true,
      suggestions,
      nextSteps: generateNextSteps(aiContent, context),
    };

    return NextResponse.json({
      success: true,
      data: response,
    });
  } catch (error: any) {
    console.error('AI chat error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to process chat message' },
      { status: 500 }
    );
  }
}

/**
 * Extract actionable suggestions from AI response
 */
function extractSuggestions(content: string): string[] {
  const suggestions: string[] = [];

  // Look for suggestions indicators
  if (content.includes('try')) {
    const match = content.match(/try\s+([^.!]+)/i);
    if (match) suggestions.push(match[1].trim());
  }

  if (content.includes('practice')) {
    const match = content.match(/practice\s+([^.!]+)/i);
    if (match) suggestions.push(match[1].trim());
  }

  if (content.includes('focus')) {
    const match = content.match(/focus\s+on\s+([^.!]+)/i);
    if (match) suggestions.push(match[1].trim());
  }

  return suggestions.slice(0, 3); // Return top 3 suggestions
}

/**
 * Generate next steps based on context
 */
function generateNextSteps(
  content: string,
  context?: ChatRequest['context']
): string[] {
  const nextSteps: string[] = [];

  if (context?.recentErrors && context.recentErrors.length > 0) {
    nextSteps.push('Review the errors we just discussed');
  }

  if (content.includes('practice')) {
    nextSteps.push('Start a practice session');
  }

  if (content.includes('next lesson')) {
    nextSteps.push('Move to the next lesson');
  }

  if (!nextSteps.length) {
    nextSteps.push('Continue practicing');
  }

  return nextSteps.slice(0, 2);
}

/**
 * Production Implementation Checklist:
 * 
 * [ ] Set OPENAI_API_KEY environment variable
 * [ ] Test with real conversations
 * [ ] Implement conversation history caching (Redis)
 * [ ] Add rate limiting to prevent abuse
 * [ ] Monitor API costs and usage
 * [ ] Implement fallback responses if API fails
 * [ ] Add conversation persistence to database
 * [ ] Create admin interface to review conversations
 * [ ] Implement content moderation
 * [ ] Add support for other LLMs (Claude, Llama, etc.)
 * [ ] Implement streaming responses for better UX
 * [ ] Add emotion detection from text
 * [ ] Create analytics for conversation quality
 * 
 * Pricing:
 * - GPT-4o: $5 per 1M input tokens, $15 per 1M output tokens
 * - GPT-4o-mini: $0.15 per 1M input tokens, $0.60 per 1M output tokens
 * - Estimate: ~$0.001-0.005 per conversation
 */
