/**
 * Authentication API Client
 * Handles API calls for authentication
 */

export const authAPI = {
  async signup(name: string, email: string, password: string) {
    const response = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Signup failed');
    }

    return response.json();
  },

  async signin(email: string, password: string) {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Login failed');
    }

    return response.json();
  },

  async signout() {
    const response = await fetch('/api/auth/logout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      throw new Error('Logout failed');
    }

    return response.json();
  },

  async getCurrentUser() {
    const response = await fetch('/api/auth/me', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      return null;
    }

    return response.json();
  },

  async resetPassword(email: string) {
    const response = await fetch('/api/auth/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Password reset failed');
    }

    return response.json();
  },
};

/**
 * User/Profile API Client
 */
export const userAPI = {
  async getProfile() {
    const response = await fetch('/api/profile', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch profile');
    }

    return response.json();
  },

  async updateProfile(data: any) {
    const response = await fetch('/api/profile', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Update failed');
    }

    return response.json();
  },

  async getStats() {
    const response = await fetch('/api/profile/stats', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch stats');
    }

    return response.json();
  },

  async getAchievements() {
    const response = await fetch('/api/achievements', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch achievements');
    }

    return response.json();
  },
};

/**
 * Learning/Lessons API Client
 */
export const learningAPI = {
  async getModules() {
    const response = await fetch('/api/modules', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch modules');
    }

    return response.json();
  },

  async getModule(id: string | number) {
    const response = await fetch(`/api/modules/${id}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch module');
    }

    return response.json();
  },

  async getLesson(id: string | number) {
    const response = await fetch(`/api/lessons/${id}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch lesson');
    }

    return response.json();
  },

  async completeLesson(lessonId: string | number, accuracy: number) {
    const response = await fetch('/api/progress/update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lessonId, accuracy, completed: true }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to complete lesson');
    }

    return response.json();
  },

  async getLessonProgress(lessonId: string | number) {
    const response = await fetch(`/api/progress/${lessonId}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch progress');
    }

    return response.json();
  },
};

/**
 * Social/Community API Client
 */
export const socialAPI = {
  async getLeaderboard(limit = 10) {
    const response = await fetch(`/api/leaderboard?limit=${limit}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch leaderboard');
    }

    return response.json();
  },

  async getFriends() {
    const response = await fetch('/api/friends', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch friends');
    }

    return response.json();
  },

  async addFriend(userId: string) {
    const response = await fetch('/api/friends', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ friendId: userId }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to add friend');
    }

    return response.json();
  },

  async removeFriend(userId: string) {
    const response = await fetch(`/api/friends/${userId}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to remove friend');
    }

    return response.json();
  },
};

/**
 * Gamification API Client
 */
export const gamificationAPI = {
  async addXP(amount: number, source: string) {
    const response = await fetch('/api/xp-system', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'add-xp', amount, source }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to add XP');
    }

    return response.json();
  },

  async updateStreak() {
    const response = await fetch('/api/xp-system', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update-streak' }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to update streak');
    }

    return response.json();
  },

  async checkBadges() {
    const response = await fetch('/api/gamification/badges', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'check' }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to check badges');
    }

    return response.json();
  },
};

/**
 * AI/ML API Client
 */
export const aiAPI = {
  async chat(message: string, context?: string) {
    const response = await fetch('/api/ai-llm-chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, context }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Chat failed');
    }

    return response.json();
  },

  async recognizeGesture(frameData: string) {
    const response = await fetch('/api/mediapipe-gesture', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ frameData }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Gesture recognition failed');
    }

    return response.json();
  },

  async detectEmotion(frameData: string) {
    const response = await fetch('/api/emotion-detection', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ frameData }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Emotion detection failed');
    }

    return response.json();
  },

  async getInLessonHint(lessonId: string | number, context?: string) {
    const response = await fetch('/api/in-lesson-guide', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lessonId, context }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to get hint');
    }

    return response.json();
  },

  async textToSpeech(text: string, speed = 1.0) {
    const response = await fetch('/api/text-to-speech', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text, speed }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Text-to-speech failed');
    }

    return response.json();
  },
};
