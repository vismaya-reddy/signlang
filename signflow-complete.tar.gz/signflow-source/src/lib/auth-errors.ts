// Comprehensive auth error handling

export enum AuthErrorType {
  INVALID_CREDENTIALS = 'INVALID_CREDENTIALS',
  EMAIL_ALREADY_EXISTS = 'EMAIL_ALREADY_EXISTS',
  WEAK_PASSWORD = 'WEAK_PASSWORD',
  INVALID_EMAIL = 'INVALID_EMAIL',
  MISSING_FIELDS = 'MISSING_FIELDS',
  NETWORK_ERROR = 'NETWORK_ERROR',
  SESSION_EXPIRED = 'SESSION_EXPIRED',
  UNAUTHORIZED = 'UNAUTHORIZED',
  UNKNOWN_ERROR = 'UNKNOWN_ERROR',
  EMAIL_NOT_CONFIRMED = 'EMAIL_NOT_CONFIRMED',
  TOO_MANY_REQUESTS = 'TOO_MANY_REQUESTS',
  INVALID_OTP = 'INVALID_OTP',
  OTP_EXPIRED = 'OTP_EXPIRED',
}

export interface AuthError {
  type: AuthErrorType;
  message: string;
  details?: Record<string, any>;
  statusCode?: number;
}

export const AUTH_ERROR_MESSAGES: Record<AuthErrorType, string> = {
  [AuthErrorType.INVALID_CREDENTIALS]: 'Invalid email or password. Please try again.',
  [AuthErrorType.EMAIL_ALREADY_EXISTS]: 'This email is already registered. Please sign in or use a different email.',
  [AuthErrorType.WEAK_PASSWORD]: 'Password must be at least 8 characters with uppercase, lowercase, number, and symbol.',
  [AuthErrorType.INVALID_EMAIL]: 'Please enter a valid email address.',
  [AuthErrorType.MISSING_FIELDS]: 'Please fill in all required fields.',
  [AuthErrorType.NETWORK_ERROR]: 'Network error. Please check your connection and try again.',
  [AuthErrorType.SESSION_EXPIRED]: 'Your session has expired. Please sign in again.',
  [AuthErrorType.UNAUTHORIZED]: 'You do not have permission to access this resource.',
  [AuthErrorType.UNKNOWN_ERROR]: 'An unexpected error occurred. Please try again.',
  [AuthErrorType.EMAIL_NOT_CONFIRMED]: 'Please confirm your email before signing in.',
  [AuthErrorType.TOO_MANY_REQUESTS]: 'Too many login attempts. Please try again later.',
  [AuthErrorType.INVALID_OTP]: 'Invalid or expired verification code.',
  [AuthErrorType.OTP_EXPIRED]: 'Verification code has expired. Please request a new one.',
};

export function parseAuthError(error: any): AuthError {
  // Handle network errors
  if (error instanceof TypeError && error.message === 'Failed to fetch') {
    return {
      type: AuthErrorType.NETWORK_ERROR,
      message: AUTH_ERROR_MESSAGES[AuthErrorType.NETWORK_ERROR],
      statusCode: 0,
    };
  }

  // Parse error message for specific error types
  const errorMsg = error?.message?.toLowerCase() || '';
  const errorStatus = error?.status;

  // Email already exists
  if (
    errorMsg.includes('already exists') ||
    errorMsg.includes('unique') ||
    errorMsg.includes('duplicate')
  ) {
    return {
      type: AuthErrorType.EMAIL_ALREADY_EXISTS,
      message: AUTH_ERROR_MESSAGES[AuthErrorType.EMAIL_ALREADY_EXISTS],
      statusCode: 409,
    };
  }

  // Invalid credentials
  if (
    errorMsg.includes('invalid') ||
    errorMsg.includes('credentials') ||
    errorMsg.includes('password') ||
    errorStatus === 400 ||
    errorStatus === 401
  ) {
    return {
      type: AuthErrorType.INVALID_CREDENTIALS,
      message: AUTH_ERROR_MESSAGES[AuthErrorType.INVALID_CREDENTIALS],
      statusCode: 401,
    };
  }

  // Weak password
  if (errorMsg.includes('password') && errorMsg.includes('weak')) {
    return {
      type: AuthErrorType.WEAK_PASSWORD,
      message: AUTH_ERROR_MESSAGES[AuthErrorType.WEAK_PASSWORD],
      statusCode: 400,
    };
  }

  // Email not confirmed
  if (errorMsg.includes('confirmed') || errorMsg.includes('verification')) {
    return {
      type: AuthErrorType.EMAIL_NOT_CONFIRMED,
      message: AUTH_ERROR_MESSAGES[AuthErrorType.EMAIL_NOT_CONFIRMED],
      statusCode: 403,
    };
  }

  // Too many requests
  if (errorStatus === 429) {
    return {
      type: AuthErrorType.TOO_MANY_REQUESTS,
      message: AUTH_ERROR_MESSAGES[AuthErrorType.TOO_MANY_REQUESTS],
      statusCode: 429,
    };
  }

  // Session expired
  if (errorStatus === 401 || errorMsg.includes('session')) {
    return {
      type: AuthErrorType.SESSION_EXPIRED,
      message: AUTH_ERROR_MESSAGES[AuthErrorType.SESSION_EXPIRED],
      statusCode: 401,
    };
  }

  // Unknown error
  return {
    type: AuthErrorType.UNKNOWN_ERROR,
    message: error?.message || AUTH_ERROR_MESSAGES[AuthErrorType.UNKNOWN_ERROR],
    statusCode: error?.status || 500,
  };
}

export function isRetryableError(error: AuthError): boolean {
  return (
    error.type === AuthErrorType.NETWORK_ERROR ||
    error.type === AuthErrorType.TOO_MANY_REQUESTS
  );
}
