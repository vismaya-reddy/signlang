import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase URL or Anon Key');
}

// Create Supabase client with auth configuration
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    // Disable email confirmation requirement
    flowType: 'implicit',
  },
});

// Auth functions
export const signUp = async (email: string, password: string, name: string) => {
  try {
    // Check if user already exists
    const { data: existingUser } = await supabase
      .from('users_profile')
      .select('id')
      .eq('email', email)
      .single();

    if (existingUser) {
      throw new Error('User with this email already exists');
    }

    // Sign up user with Supabase Auth
    // NOTE: Email confirmation disabled to avoid rate limits
    // To enable email confirmation in production:
    // 1. Go to Supabase Dashboard > Authentication > Providers > Email
    // 2. Enable "Confirm email" option
    // 3. Configure email templates
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: name,
        },
        // Email confirmation is disabled - users are auto-verified
        // Remove this line to enable email confirmation in production
        emailRedirectTo: undefined,
      },
    });

    if (error) {
      // Handle rate limit error specifically
      if (error.message && error.message.includes('rate limit')) {
        throw new Error('Too many signup attempts. Please wait a few minutes and try again.');
      }
      throw error;
    }

    // Create user profile in database immediately
    if (data.user) {
      const profileError = await createUserProfile(data.user.id, name, email);
      if (profileError) throw profileError;
    }

    return data;
  } catch (error: any) {
    throw new Error(error.message || 'Signup failed');
  }
};

export const signIn = async (email: string, password: string) => {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      if (error.status === 400) {
        throw new Error('Invalid email or password');
      }
      throw error;
    }

    // Fetch user profile
    if (data.user) {
      const profile = await getUserProfile(data.user.id);
      return { user: data.user, session: data.session, profile };
    }

    return data;
  } catch (error: any) {
    throw new Error(error.message || 'Login failed');
  }
};

export const signInWithGoogle = async () => {
  try {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/auth/callback`,
      },
    });

    if (error) throw error;
    return data;
  } catch (error: any) {
    throw new Error(error.message || 'Google sign-in failed');
  }
};

export const signInWithGitHub = async () => {
  try {
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'github',
      options: {
        redirectTo: `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/auth/callback`,
      },
    });

    if (error) throw error;
    return data;
  } catch (error: any) {
    throw new Error(error.message || 'GitHub sign-in failed');
  }
};

export const signOut = async () => {
  try {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  } catch (error: any) {
    throw new Error(error.message || 'Logout failed');
  }
};

export const getCurrentUser = async () => {
  try {
    const { data, error } = await supabase.auth.getUser();
    if (error) throw error;
    return data.user;
  } catch (error: any) {
    return null;
  }
};

export const getCurrentSession = async () => {
  try {
    const { data, error } = await supabase.auth.getSession();
    if (error) throw error;
    return data.session;
  } catch (error: any) {
    return null;
  }
};

// Database functions
export const createUserProfile = async (userId: string, name: string, email: string) => {
  try {
    const { data, error } = await supabase
      .from('users_profile')
      .insert([
        {
          user_id: userId,
          name,
          email,
          level: 1,
          xp: 0,
          current_streak: 0,
          longest_streak: 0,
          total_lessons_completed: 0,
        },
      ])
      .select();

    if (error) {
      console.error('Error creating user profile:', error);
      return error;
    }
    return data?.[0];
  } catch (error: any) {
    console.error('Error in createUserProfile:', error);
    return error;
  }
};

export const getUserProfile = async (userId: string) => {
  try {
    const { data, error } = await supabase
      .from('users_profile')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error && error.code !== 'PGRST116') {
      console.error('Error fetching user profile:', error);
      return null;
    }
    return data;
  } catch (error: any) {
    console.error('Error in getUserProfile:', error);
    return null;
  }
};

export const updateUserProfile = async (userId: string, updates: any) => {
  try {
    const { data, error } = await supabase
      .from('users_profile')
      .update(updates)
      .eq('user_id', userId)
      .select();

    if (error) throw error;
    return data?.[0];
  } catch (error: any) {
    console.error('Error updating user profile:', error);
    throw error;
  }
};

export const getUserProgress = async (userId: string) => {
  const { data, error } = await supabase
    .from('user_progress')
    .select('*, lessons(*)')
    .eq('user_id', userId);

  if (error) throw error;
  return data || [];
};

export const updateUserProgress = async (
  userId: string,
  lessonId: string,
  completed: boolean,
  accuracyScore: number
) => {
  const { data, error } = await supabase
    .from('user_progress')
    .upsert(
      {
        user_id: userId,
        lesson_id: lessonId,
        completed,
        accuracy_score: accuracyScore,
        attempts: 1,
        last_attempted: new Date().toISOString(),
        ...(completed && { completed_at: new Date().toISOString() }),
      },
      { onConflict: 'user_id,lesson_id' }
    )
    .select();

  if (error) throw error;
  return data?.[0];
};

export const getModules = async () => {
  const { data, error } = await supabase
    .from('modules')
    .select('*, lessons(*)')
    .order('order_index', { ascending: true });

  if (error) throw error;
  return data || [];
};

export const getModule = async (moduleId: string) => {
  const { data, error } = await supabase
    .from('modules')
    .select('*, lessons(*)')
    .eq('id', moduleId)
    .single();

  if (error) throw error;
  return data;
};

export const getLesson = async (lessonId: string) => {
  const { data, error } = await supabase
    .from('lessons')
    .select('*')
    .eq('id', lessonId)
    .single();

  if (error) throw error;
  return data;
};

export const addXP = async (userId: string, xpAmount: number, lessonId?: string) => {
  // Add to daily log
  const { error: logError } = await supabase
    .from('daily_xp_log')
    .insert([
      {
        user_id: userId,
        lesson_id: lessonId,
        xp_earned: xpAmount,
      },
    ]);

  if (logError && logError.code !== '23505') throw logError; // Ignore duplicate key errors

  // Update user's total XP
  const { data: userData, error: userError } = await supabase
    .from('users')
    .select('xp, level')
    .eq('id', userId)
    .single();

  if (userError) throw userError;

  const newXP = (userData?.xp || 0) + xpAmount;
  const newLevel = Math.floor(newXP / 1000) + 1;

  const { data, error } = await supabase
    .from('users')
    .update({
      xp: newXP,
      level: newLevel,
    })
    .eq('id', userId)
    .select();

  if (error) throw error;
  return data?.[0];
};

export const updateStreak = async (userId: string) => {
  const today = new Date().toISOString().split('T')[0];

  const { data: userData } = await supabase
    .from('users')
    .select('last_practice_date, current_streak, longest_streak')
    .eq('id', userId)
    .single();

  let newStreak = userData?.current_streak || 0;
  let newLongestStreak = userData?.longest_streak || 0;

  const lastDate = userData?.last_practice_date ? new Date(userData.last_practice_date) : null;
  const todayDate = new Date(today);
  const yesterday = new Date(todayDate);
  yesterday.setDate(yesterday.getDate() - 1);

  if (lastDate) {
    const daysDiff = Math.floor(
      (todayDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24)
    );

    if (daysDiff === 0) {
      // Already practiced today
      return userData;
    } else if (daysDiff === 1) {
      // Consecutive day
      newStreak += 1;
    } else {
      // Streak broken
      newStreak = 1;
    }
  } else {
    newStreak = 1;
  }

  if (newStreak > newLongestStreak) {
    newLongestStreak = newStreak;
  }

  const { data, error } = await supabase
    .from('users')
    .update({
      last_practice_date: today,
      current_streak: newStreak,
      longest_streak: newLongestStreak,
    })
    .eq('id', userId)
    .select();

  if (error) throw error;
  return data?.[0];
};

export const getFriends = async (userId: string) => {
  const { data, error } = await supabase
    .from('friendships')
    .select('*, friend:friend_id(id, name, avatar_url, level, xp)')
    .eq('user_id', userId)
    .eq('status', 'accepted');

  if (error) throw error;
  return data || [];
};

export const addFriend = async (userId: string, friendId: string) => {
  const { data, error } = await supabase
    .from('friendships')
    .insert([
      {
        user_id: userId,
        friend_id: friendId,
        status: 'accepted',
      },
    ])
    .select();

  if (error) throw error;
  return data?.[0];
};

export const removeFriend = async (userId: string, friendId: string) => {
  const { error } = await supabase
    .from('friendships')
    .delete()
    .eq('user_id', userId)
    .eq('friend_id', friendId);

  if (error) throw error;
};

export const getLeaderboard = async (limit = 10) => {
  const { data, error } = await supabase
    .from('users')
    .select('id, name, avatar_url, level, xp, current_streak')
    .order('xp', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data || [];
};

export const getAchievements = async (userId: string) => {
  const { data, error } = await supabase
    .from('user_achievements')
    .select('*, achievement:achievement_id(*)')
    .eq('user_id', userId);

  if (error) throw error;
  return data || [];
};

export const awardAchievement = async (userId: string, achievementId: string) => {
  const { data, error } = await supabase
    .from('user_achievements')
    .insert([
      {
        user_id: userId,
        achievement_id: achievementId,
      },
    ])
    .select();

  if (error && error.code !== '23505') throw error; // Ignore duplicate key errors
  return data?.[0];
};

export const createConversation = async (userId: string, title: string) => {
  const { data, error } = await supabase
    .from('conversations')
    .insert([
      {
        user_id: userId,
        title,
      },
    ])
    .select();

  if (error) throw error;
  return data?.[0];
};

export const getConversations = async (userId: string) => {
  const { data, error } = await supabase
    .from('conversations')
    .select('*')
    .eq('user_id', userId)
    .order('updated_at', { ascending: false });

  if (error) throw error;
  return data || [];
};

export const addMessage = async (
  conversationId: string,
  userId: string,
  role: 'user' | 'assistant',
  content: string,
  hasAudio = false,
  hasSignAnimation = false
) => {
  const { data, error } = await supabase
    .from('messages')
    .insert([
      {
        conversation_id: conversationId,
        user_id: userId,
        role,
        content,
        has_audio: hasAudio,
        has_sign_animation: hasSignAnimation,
      },
    ])
    .select();

  if (error) throw error;
  return data?.[0];
};

export const getMessages = async (conversationId: string) => {
  const { data, error } = await supabase
    .from('messages')
    .select('*')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true });

  if (error) throw error;
  return data || [];
};
